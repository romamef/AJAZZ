/* global addDynamicStyles, $SD, Utils */
/* eslint-disable no-extra-boolean-cast */

/**
 * GIF Player Property Inspector
 * Исправленная загрузка сохраненных настроек
 */

// Глобальные переменные
let currentSettings = {};
let isInitialized = false;
let isConnected = false;

document.addEventListener('DOMContentLoaded', function() {
    console.log('GIF Player Property Inspector loaded');
    
    // Инициализация
    initializePI();
});

function initializePI() {
    if (isInitialized) return;
    
    console.log('Initializing PI...');
    
    // Настройка обработчиков событий $SD
    setupSDHandlers();
    
    // Если $SD уже подключен, запускаем инициализацию
    if ($SD && $SD.uuid) {
        onSDConnected();
    }
    
    isInitialized = true;
}

function setupSDHandlers() {
    if (!$SD) {
        console.warn('$SD not available yet');
        return;
    }
    
    // Подключаемся при соединении
    $SD.on('connected', function(data) {
        console.log('PI connected to StreamDock');
        isConnected = true;
        onSDConnected(data);
    });
    
    // Динамические стили
    if (typeof addDynamicStyles !== 'undefined') {
        $SD.on('connected', function(data) {
            addDynamicStyles($SD.applicationInfo.colors, 'connectSocket');
        });
    }
    
    // Локализация
    $SD.on('localizationLoaded', function() {
        console.log('Localization loaded');
        localizeUI();
    });
    
    // Сообщения от плагина
    $SD.on('sendToPropertyInspector', function(data) {
        console.log('Message from plugin:', data);
        // Можно обработать ответы от плагина
    });
}

function onSDConnected(data) {
    console.log('onSDConnected called');
    
    if (data && data.actionInfo && data.actionInfo.payload && data.actionInfo.payload.settings) {
        console.log('Settings from connection:', data.actionInfo.payload.settings);
        loadSavedSettings(data.actionInfo.payload.settings);
    } else {
        console.log('No settings in connection data, requesting...');
        // Запрашиваем настройки если их нет
        setTimeout(requestSettings, 100);
    }
    
    // Локализация
    localizeUI();
    
    // Настройка обработчиков UI
    setupUIEventListeners();
}

function requestSettings() {
    if ($SD && $SD.api && $SD.uuid) {
        console.log('Requesting settings from plugin...');
        $SD.api.getSettings($SD.uuid);
    }
}

/**
 * Загрузка сохраненных настроек (ОСНОВНОЕ ИСПРАВЛЕНИЕ)
 */
function loadSavedSettings(savedSettings) {
    console.log('Loading saved settings:', savedSettings);
    
    if (!savedSettings || typeof savedSettings !== 'object') {
        console.log('No valid settings to load');
        return;
    }
    
    // Сохраняем текущие настройки
    currentSettings = { ...savedSettings };
    
    // Обновляем UI с задержкой для гарантии загрузки DOM
    setTimeout(() => {
        updateUIWithSettings(savedSettings);
    }, 50);
}

function updateUIWithSettings(settings) {
    console.log('Updating UI with settings:', settings);
    
    // FPS (обязательно число)
    if (settings.fps !== undefined) {
        const fpsSlider = document.getElementById('fps');
        const fpsValue = document.getElementById('fps-value');
        
        if (fpsSlider && fpsValue) {
            const fps = parseInt(settings.fps) || 10;
            fpsSlider.value = fps;
            fpsValue.textContent = fps;
            console.log('FPS set to:', fps);
        }
    }
    
    // Start Animation (обязательно число)
    if (settings.startAnimation !== undefined) {
        const startAnimInput = document.getElementById('startAnimation');
        if (startAnimInput) {
            const startAnim = parseInt(settings.startAnimation) || 1;
            startAnimInput.value = startAnim;
            console.log('Start Animation set to:', startAnim);
        }
    }
    
    // Animations Folder
    if (settings.animationsFolder !== undefined) {
        const folderInput = document.getElementById('animationsFolder');
        if (folderInput) {
            folderInput.value = settings.animationsFolder;
            console.log('Animations Folder set to:', settings.animationsFolder);
        }
    }
    
    // Max Frames (обязательно число)
    if (settings.maxFrames !== undefined) {
        const maxFramesInput = document.getElementById('maxFrames');
        if (maxFramesInput) {
            const maxFrames = parseInt(settings.maxFrames) || 100;
            maxFramesInput.value = maxFrames;
            console.log('Max Frames set to:', maxFrames);
        }
    }
}

/**
 * Локализация интерфейса
 */
function localizeUI() {
    if (!window.$localizedStrings) {
        console.log('No localization strings available');
        return;
    }
    
    const el = document.querySelector('.sdpi-wrapper') || document;
    
    // Локализация элементов с data-locale
    Array.from(el.querySelectorAll('[data-locale]')).forEach(e => {
        const localeKey = e.getAttribute('data-locale');
        if (localeKey && window.$localizedStrings[localeKey]) {
            const translated = window.$localizedStrings[localeKey];
            if (e.textContent !== translated) {
                e.textContent = translated;
            }
        }
    });
    
    // Локализация текстовых узлов
    Array.from(el.querySelectorAll('*:not(script):not(style)')).forEach(e => {
        if (e.childNodes && e.childNodes.length > 0) {
            const textNode = e.childNodes[0];
            if (textNode.nodeType === Node.TEXT_NODE) {
                const text = textNode.nodeValue.trim();
                if (text && window.$localizedStrings[text]) {
                    const translated = window.$localizedStrings[text];
                    if (text !== translated) {
                        textNode.nodeValue = textNode.nodeValue.replace(text, translated);
                    }
                }
            }
        }
    });
}

/**
 * Настройка обработчиков UI событий
 */
function setupUIEventListeners() {
    console.log('Setting up UI event listeners');
    
    // FPS слайдер
    const fpsSlider = document.getElementById('fps');
    const fpsValue = document.getElementById('fps-value');
    
    if (fpsSlider && fpsValue) {
        let fpsTimeout;
        
        fpsSlider.addEventListener('input', function() {
            const value = parseInt(this.value) || 10;
            fpsValue.textContent = value;
            
            // Дебаунс для сохранения
            clearTimeout(fpsTimeout);
            fpsTimeout = setTimeout(() => {
                saveSetting('fps', value);
            }, 300);
        });
        
        fpsSlider.addEventListener('change', function() {
            const value = parseInt(this.value) || 10;
            saveSetting('fps', value);
        });
        
        console.log('FPS slider listener setup');
    }
    
    // Остальные поля
    const fields = [
        { id: 'startAnimation', type: 'number', default: 1 },
        { id: 'animationsFolder', type: 'string', default: 'gif' },
        { id: 'maxFrames', type: 'number', default: 100 }
    ];
    
    fields.forEach(field => {
        const input = document.getElementById(field.id);
        if (input) {
            let timeoutId;
            
            input.addEventListener('input', function() {
                clearTimeout(timeoutId);
                timeoutId = setTimeout(() => {
                    let value = this.value;
                    
                    if (field.type === 'number') {
                        value = parseInt(value) || field.default;
                        this.value = value; // Обновляем поле
                    }
                    
                    saveSetting(field.id, value);
                }, 500);
            });
            
            input.addEventListener('change', function() {
                let value = this.value;
                
                if (field.type === 'number') {
                    value = parseInt(value) || field.default;
                    this.value = value;
                }
                
                saveSetting(field.id, value);
            });
            
            console.log(`${field.id} listener setup`);
        }
    });
}

/**
 * Сохранение настройки
 */
function saveSetting(key, value) {
    console.log(`Saving setting: ${key} = ${value} (type: ${typeof value})`);
    
    // Обновляем текущие настройки
    currentSettings[key] = value;
    
    // Отправляем в плагин
    if ($SD && $SD.api && $SD.uuid) {
        // Формат как в часах
        const sdpi_collection = {
            key: key,
            value: value,
            group: false,
            index: 0,
            selection: [],
            checked: false
        };
        
        // Отправляем в плагин
        $SD.api.sendToPlugin($SD.uuid, 'com.mef.gifplayer.action', {
            sdpi_collection: sdpi_collection
        });
        
        // Сохраняем настройки в StreamDock
        $SD.api.setSettings($SD.uuid, currentSettings);
        
        console.log(`✅ Setting "${key}" saved:`, value);
    }
}

/**
 * Обработчик didReceiveSettings (если плагин отправляет настройки)
 */
if ($SD) {
    // Обработка события получения настроек
    const originalOn = $SD.on;
    $SD.on = function(event, callback) {
        if (event === 'didReceiveSettings') {
            // Перехватываем didReceiveSettings
            originalOn.call($SD, event, function(data) {
                console.log('didReceiveSettings event:', data);
                if (data.payload && data.payload.settings) {
                    loadSavedSettings(data.payload.settings);
                }
                if (callback) callback(data);
            });
        } else {
            originalOn.call($SD, event, callback);
        }
    };
}

// Fallback инициализация
setTimeout(function() {
    if (!isConnected && $SD && $SD.uuid) {
        console.log('Fallback initialization');
        onSDConnected();
    }
    
    // Проверяем загрузились ли настройки
    const fpsSlider = document.getElementById('fps');
    if (fpsSlider && fpsSlider.value === '10' && Object.keys(currentSettings).length === 0) {
        console.log('Settings may not have loaded, checking URL params...');
        
        // Попробуем получить настройки из URL (если есть)
        const urlParams = new URLSearchParams(window.location.search);
        const settingsParam = urlParams.get('settings');
        
        if (settingsParam) {
            try {
                const settings = JSON.parse(decodeURIComponent(settingsParam));
                loadSavedSettings(settings);
            } catch (e) {
                console.error('Failed to parse settings from URL:', e);
            }
        }
    }
}, 1000);

console.log('GIF Player PI script loaded');