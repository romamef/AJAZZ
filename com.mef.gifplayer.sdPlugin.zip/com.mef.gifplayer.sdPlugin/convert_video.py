#!/usr/bin/env python3

import argparse
import json
import os
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description='Convert video to PNG frames for Stream Deck')
    parser.add_argument('video', help='Path to video file')
    parser.add_argument('output', nargs='?', default='./01',
                        help='Output folder: 01 ... 015 (default: ./01)')
    parser.add_argument('--fps', type=int, default=15,
                        help='Frames per second to extract (default: 15)')
    parser.add_argument('--size', type=int, default=144,
                        help='Frame size in pixels (default: 144, square)')
    args = parser.parse_args()

    video_path = Path(args.video)
    if not video_path.exists():
        print(f'Error: Video file not found: {video_path}')
        sys.exit(1)

    output_path = Path(args.output)
    output_path.mkdir(parents=True, exist_ok=True)

    try:
        import cv2
    except ImportError:
        print('Error: OpenCV required. Install with: pip install opencv-python')
        sys.exit(1)

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f'Error: Cannot open video: {video_path}')
        sys.exit(1)

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    video_fps = args.fps
    frame_interval = max(1, int(fps / video_fps))

    print(f'Video: {video_path}')
    print(f'Video FPS: {fps}, Total frames: {total_frames}')
    print(f'Extracting at {video_fps} FPS (every {frame_interval} frames)')
    print(f'Output: {output_path}')
    print(f'Frame size: {args.size}x{args.size}')

    frame_count = 0
    extracted = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if frame_count % frame_interval == 0:
            resized = cv2.resize(frame, (args.size, args.size))
            filename = output_path / f'{extracted + 1:01d}.png'
            cv2.imwrite(str(filename), resized)
            extracted += 1

            if extracted % 100 == 0:
                print(f'  Extracted {extracted} frames...')

        frame_count += 1

    cap.release()

    metadata = {
        'frameCount': extracted,
        'fps': video_fps,
        'size': args.size
    }
    with open(output_path / 'metadata.json', 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2)

    print(f'Done! Extracted {extracted} frames.')
    print(f'Metadata saved to {output_path / "metadata.json"}')


if __name__ == '__main__':
    main()
