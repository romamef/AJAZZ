// Пустой файл, но он должен существовать
console.log('common_pi.js loaded');