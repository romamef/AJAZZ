#!/usr/bin/env python3
"""Convert video to PNG/JPEG frames for the GIF Player plugin.

Frames are sampled by TIME, so the real rate always matches --fps
(set the same FPS in the plugin settings).
"""

import argparse
import json
import sys
from pathlib import Path

try:
    import cv2
except ImportError:
    print('Error: OpenCV required. Install with: pip install opencv-python')
    sys.exit(1)

MAX_FRAMES_LIMIT = 999  # plugin limit per animation folder


def to_square(frame, size, stretch):
    """Crop the center to a square (or stretch) and resize to size x size."""
    h, w = frame.shape[:2]
    if not stretch and h != w:
        side = min(h, w)
        y, x = (h - side) // 2, (w - side) // 2
        frame = frame[y:y + side, x:x + side]
    return cv2.resize(frame, (size, size), interpolation=cv2.INTER_AREA)


def main():
    parser = argparse.ArgumentParser(
        description='Convert video to PNG/JPEG frames for GIF Player')
    parser.add_argument('video', help='Path to video file')
    parser.add_argument('output', nargs='?', default='./001',
                        help='Output folder, 3 digits: 001 ... 999 (default: ./001)')
    parser.add_argument('--fps', type=int, default=10,
                        help='Frames per second to extract = FPS in the plugin (default: 10)')
    parser.add_argument('--size', type=int, default=144,
                        help='Frame size in pixels (default: 144, square)')
    parser.add_argument('--max-frames', type=int, default=MAX_FRAMES_LIMIT,
                        help=f'Stop after N frames (default/max: {MAX_FRAMES_LIMIT})')
    parser.add_argument('--stretch', action='store_true',
                        help='Stretch to a square instead of cropping the center')
    parser.add_argument('--format', choices=['png', 'jpg'], default='png',
                        help='Output format (default: png)')
    parser.add_argument('--quality', type=int, default=90,
                        help='JPEG quality 1-100 (default: 90, used only with --format jpg)')
    args = parser.parse_args()

    if args.fps < 1:
        print('Error: --fps must be at least 1')
        sys.exit(1)
    if args.size < 1:
        print('Error: --size must be at least 1')
        sys.exit(1)
    quality = max(1, min(100, args.quality))

    video_path = Path(args.video)
    if not video_path.exists():
        print(f'Error: Video file not found: {video_path}')
        sys.exit(1)

    # Plugin looks for 3-digit folders (001, 002, ...)
    output_path = Path(args.output)
    if output_path.name.isdigit() and len(output_path.name) != 3:
        output_path = output_path.with_name(output_path.name.zfill(3))

    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        print(f'Error: Cannot open video: {video_path}')
        sys.exit(1)

    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    max_frames = max(1, min(args.max_frames, MAX_FRAMES_LIMIT))

    target_fps = float(args.fps)
    if target_fps > src_fps:
        print(f"Warning: source is {src_fps:.2f} fps, can't extract {args.fps}. "
              f'Using {src_fps:.2f}; set the plugin FPS to about {round(src_fps)}.')
        target_fps = src_fps

    output_path.mkdir(parents=True, exist_ok=True)
    duration = total_frames / src_fps if total_frames > 0 else 0

    print(f'Video: {video_path}  ({src_fps:.2f} fps, {total_frames} frames, ~{duration:.1f}s)')
    print(f'Extracting at {target_fps:g} fps -> ~{int(duration * target_fps)} frames '
          f'(limit {max_frames})')
    print(f'Output: {output_path}   Size: {args.size}x{args.size}   Format: {args.format}'
          + (f' (quality {quality})' if args.format == 'jpg' else ''))

    write_params = [cv2.IMWRITE_JPEG_QUALITY, quality] if args.format == 'jpg' else []

    step = 1.0 / target_fps
    next_time = 0.0
    index = 0
    extracted = 0

    while extracted < max_frames:
        ret, frame = cap.read()
        if not ret:
            break

        t = index / src_fps
        index += 1
        if t + 1e-9 < next_time:
            continue
        next_time += step

        extracted += 1
        out_file = output_path / f'{extracted}.{args.format}'
        img = to_square(frame, args.size, args.stretch)
        if not cv2.imwrite(str(out_file), img, write_params):
            print(f'Error: cannot write {out_file}')
            sys.exit(1)

        if extracted % 100 == 0:
            print(f'  Extracted {extracted} frames...')

    cap.release()

    if extracted == max_frames:
        print(f'Note: stopped at the frame limit ({max_frames}); the rest of the video was skipped.')

    metadata = {
        'frameCount': extracted,
        'fps': round(target_fps, 3),
        'size': args.size,
        'format': args.format
    }
    with open(output_path / 'metadata.json', 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2)

    print(f'Done! Extracted {extracted} frames (~{extracted / target_fps:.1f}s at {target_fps:g} fps).')
    print(f'In the plugin: Animations Folder = parent of "{output_path.name}", '
          f'Start Animation = {int(output_path.name) if output_path.name.isdigit() else output_path.name}, '
          f'FPS = {round(target_fps)}, Max Frames >= {extracted}.')


if __name__ == '__main__':
    main()